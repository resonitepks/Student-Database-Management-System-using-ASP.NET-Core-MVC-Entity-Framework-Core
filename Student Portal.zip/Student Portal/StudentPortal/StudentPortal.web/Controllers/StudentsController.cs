﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StudentPortal.web.Data;
using StudentPortal.web.Models;
using StudentPortal.web.Models.Entities;

namespace StudentPortal.web.Controllers
{
    public class StudentsController : Controller
    {
        private ApplicationDbcontext dbcontext;

        public StudentsController(ApplicationDbcontext dbcontext)
        {
            this.dbcontext = dbcontext; 
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(AddStudentViewModal viewModal)
        {
            return View();

        }
        [HttpPost]
        public async Task<IActionResult> Add(AddStudentViewModal viewModal)
        {
            var student = new Student
            {
                Name = viewModal.Name,
                Email = viewModal.Email,
                phone = viewModal.phone,
                Subscribed = viewModal.Subscribed,

            };
            await dbcontext.Students.AddAsync(student);
            await dbcontext.SaveChangesAsync();
            return View();
        }

        [HttpGet]
        public async Task<IActionResult> List()

        {
            var students = await dbcontext.Students.ToListAsync();
            return View(students);
        }

        [HttpGet]
        public async Task<IActionResult> Edit(Guid Id)
        {
            var student = await dbcontext.Students.FindAsync(Id);
            return View(student);

        }
        [HttpPost]
        public async Task<IActionResult> Edit(Student viewModel)
        {
            var student = await dbcontext.Students.FindAsync(viewModel.Id);
            if(student is not null)
            {
                student.Name = viewModel.Name;
                student.Email = viewModel.Email;
                student.phone = viewModel.phone;
                student.Subscribed = viewModel.Subscribed;

                await dbcontext.SaveChangesAsync();
            }
            return RedirectToAction("List", "Students");


        }
        [HttpPost]
        public async Task<IActionResult> Delete(Student viewModel)
        {
            var student = await dbcontext.Students
                .AsNoTracking()
                .FirstOrDefaultAsync(x=> x.Id==viewModel.Id);
            if (student is not null)
            {

                dbcontext.Students.Remove(viewModel);
                await dbcontext.SaveChangesAsync();
            }
            return RedirectToAction("List", "Students");

        }

    }
}
